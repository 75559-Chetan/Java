package tester;

import static utils.BankUtils.deleteByacc_number;
import static utils.BankUtils.findByacc_number;
import static utils.BankValidationRules.validateAllInputs;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

import com.bank.core.Bank;
import com.bank.core.Type;

import custom_ordering.BankAccountCreationComparator;
import custom_ordering.BankBalanceComp;

public class BankManagement {

	public static void main(String[] args) {
		// create a scanner
		try (Scanner sc = new Scanner(System.in)) {
			ArrayList<Bank> banks = new ArrayList<>();
			boolean exit = false;
			while (!exit) {
				try {
					System.out.println("Options : 1. Create Bank Account " + "2. View account summary\n "
							+ "3. Deposit funds 4. Withdraw funds\n " + "5. Close Account"
							+ "6.Sort bank accounts as per acct nos (asc) , using natural orderin/n"
							+ "7.Sort bank accounts as per account creation date  , using custom ordering"
							+ "8.Sort bank accounts as per account type n balance  , using custom ordering\r\n"
							+ "9. Get Sorted Details"+"0. Exit");
					System.out.println("Choose an option");
					switch (sc.nextInt()) {
					case 1:
						System.out.println("Enter account details:acct number , customer name, "
								+ "pin , account type (SAVING,CURRENT,FD,LOAN) ," + " account balance , creation date");
						Bank bank = validateAllInputs(sc.nextInt(), sc.next(), sc.next(), Type.valueOf(sc.next()),
								sc.nextDouble(), LocalDate.parse(sc.next()), banks);
						banks.add(bank);

						break;

					case 2:
						System.out.println("Enter Account number:");
						System.out.println(findByacc_number(sc.nextInt(), banks));
						break;
					case 3:
						System.out.println("Enter Account no and Deposit Amount");
						int acc_number = sc.nextInt();
						double depositamount = sc.nextDouble();
						bank = findByacc_number(acc_number, banks);
						bank.setBalance(bank.getBalance() + depositamount);
						System.out.println("Money Deposited Successfully!!");
						break;

					case 4:
						System.out.println("Enter Account Number :  ");
						acc_number = sc.nextInt();
						System.out.println("Withdrawal amount : ");
						double withdrawamount = sc.nextDouble();
						bank = findByacc_number(acc_number, banks);
						bank.setBalance(bank.getBalance() - withdrawamount);
						System.out.println("Money withdrawal successfully !!");
						break;

					case 5:
						System.out.println("Enter account number :  ");
						System.out.println(deleteByacc_number(sc.nextInt(), banks));

						break;
					case 6:
						System.out.println("Bank Accouts Sorted as per Account Number");
						Collections.sort(banks);
						break;
					case 7:
						System.out.println("Bank Accounts Sorted as per Opening Date");
						Collections.sort(banks, new BankAccountCreationComparator());

						break;
					case 8:
						System.out.println("Bank Accounts Sorted as per Account Balance");
						Collections.sort(banks, new BankBalanceComp());
						break;
					case 9:
						for (Bank i : banks) {
							System.out.println(findByacc_number(i.getAcc_number(), banks));

						}

						break;
					case 0:
						exit = true;
						break;
					}
				} catch (Exception e) {
					System.out.println(e);
					System.out.println("Pls retry...");
					sc.nextLine();
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
