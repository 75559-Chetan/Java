package com.bank.core;

import java.time.LocalDate;

public class Bank implements Comparable<Bank>{
	private int acc_number;

	private String customer_name;
	private String pin;
	private Type acc_type;
	private double balance;
	private LocalDate openingDate;

	public Bank(int acc_number, String customer_name, String pin, Type acc_type, double balance,
			LocalDate openingDate) {
		super();
		this.acc_number = acc_number;
		this.customer_name = customer_name;
		this.pin = pin;
		this.acc_type = acc_type;
		this.balance = balance;
		this.openingDate = openingDate;
	}

	public Bank(int newaccNumber) {
		this.acc_number = newaccNumber;
	}

	@Override
	public String toString() {
		return "Bank [acc_number=" + acc_number + ", customer_name=" + customer_name + ", pin=" + pin + ", acc_type="
				+ acc_type + ", balance=" + balance + ", openingDate=" + openingDate + "]";
	}

	public boolean equals(Object o) {
		if (this.acc_number == ((Bank) o).acc_number)
			return true;
		return false;

	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public LocalDate getOpeningDate() {
		return openingDate;
	}

	@Override
	public int compareTo(Bank anotherBank) {
		System.out.println("in compare to ");
	if(this.acc_number==anotherBank.acc_number)
	{	return 0;
	}
	else if(this.acc_number>anotherBank.acc_number)
		return 1;
	return -1;
}

	public int getAcc_number() {
		return acc_number;
	}

	public void setAcc_number(int acc_number) {
		this.acc_number = acc_number;
	}
	
}
