package com.bank.core;

public enum Type {
SAVING,CURRENT,FD,LOAN
}
