package custom_ordering;

import java.util.Comparator;

import com.bank.core.Bank;

public class BankAccountCreationComparator implements Comparator<Bank> {
	@Override
	public int compare(Bank o1, Bank o2) {
		System.out.println("In Compare Account Creation");
		int ret = o1.getOpeningDate().compareTo(o2.getOpeningDate());
		if (ret == 0) {
			if (o1.getBalance() < o2.getBalance())
				return 1;
			if (o1.getBalance() == o2.getBalance())
				return 0;

		}
		return ret;

	}

}
