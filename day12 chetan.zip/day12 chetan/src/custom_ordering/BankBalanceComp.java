package custom_ordering;

import java.util.Comparator;

import com.bank.core.Bank;

public class BankBalanceComp implements Comparator<Bank> {
	@Override
	public int compare(Bank o1, Bank o2) {
		System.out.println("in compare Account Balance");

		if (o1.getBalance() < o2.getBalance())
			return 1;
		if (o1.getBalance() == o2.getBalance())
			return 0;
		return -1;

	}
}
