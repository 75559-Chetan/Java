package utils;

import com.bank.core.Bank;
import java.util.ArrayList;
import custom_exception.InvalidInputException;

public class BankUtils {
public static Bank findByacc_number(int acc_number ,ArrayList<Bank> banks) throws InvalidInputException {
	Bank b = new Bank(acc_number);
	int index = banks.indexOf(b);
	if (index == -1)
		throw new InvalidInputException("Account not Found !!");
	return banks.get(index);
}

public static Bank deleteByacc_number(int acc_number, ArrayList<Bank> banks) throws InvalidInputException {
	Bank b = new Bank(acc_number);
	int index = banks.indexOf(b);
	if (index == -1)
		throw new InvalidInputException("account not found!!!!");
	
	return banks.remove(index);
}





}
