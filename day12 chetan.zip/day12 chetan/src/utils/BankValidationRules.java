package utils;
import java.time.LocalDate;
import java.util.ArrayList;

import com.bank.core.Bank;
import com.bank.core.Type;

import custom_exception.InvalidInputException;
public class BankValidationRules {
	public static void checkforDups(int newaccNumber,ArrayList<Bank> banks) throws InvalidInputException 
	{
		Bank newBank=new Bank(newaccNumber);
		if(banks.contains(newBank))
			throw new InvalidInputException("Duplicate account found !!!");
		System.out.println("Account Added Sucessfully !!");
	}
	
	
	
	
	
	
	
	
	
	public static Bank validateAllInputs(int acc_number,String customer_name,String pin,Type acc_type, double balance,
			LocalDate openingDate,ArrayList<Bank> banks) throws InvalidInputException
	{
		checkforDups(acc_number,banks);
		
		
		return new Bank(acc_number,customer_name,pin,acc_type,balance,openingDate);
		
		
		
		
		
		
	}
}
